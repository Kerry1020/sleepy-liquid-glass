# 同一多色五角星：第三个 G 幅度

**这是颜色诊断，产品仍为 r2 未验收检查点。** 五／六／八角星继续用于形变对照，七角星未采集。

原 G128 多色 control 与 G232 witness 已有原生捕获。本轮只补 G180 midpoint 和完全相同的 G128 control 复拍，继续使用原五角星轮廓、RGB 分区、16pt 大小、coverage16、sRGB ICC 和源坐标；R/B 源逐字节不变。两轮均复用原二进制，无新构建，各有 12 个真实 held endpoint／6 对 shape-flat，严格检查通过。

## 原始字节结果

- 四轮实际 carrier、center、presentation matrix、opacity、源映射的最大跨轮变化均为 0。
- 每一轮 flat 相对旧 control flat 的 RGB 最大绝对差为 0。
- 重复 control 的 shape-minus-flat 在整个固定 ROI 内相对旧 control 逐字节完全相同，三个通道的最大差均为 0。
- `E=(H−Hflat)−0.5(F−Fflat)−0.5(C−Cflat)`，共享同一个 control；复拍 control 仅用于漂移检查。
- 固定 ROI、轨道上方 `y<422`：除 full100 红通道五个像素外，全部 E 在 ±1.5 byte 内。五个像素中三个 |E|>4，最大 7.5；没有 |E|>8。绿／蓝在全部六姿态均无 |E|>1.5。不是全局“通过”或所有背景的线性证明。

| 原生坐标 pt | carrier inset pt | Control RGB | Half RGB | Full RGB | E_R |
|---|---:|---|---|---|---:|
| 183.25,411.25 | .35 | 23,91,175 | 9,110,164 | 5,127,153 | −5 |
| 183.75,411.25 | .35 | 22,94,113 | 6,119,101 | 5,145,87 | −7.5 |
| 184.25,411.25 | .35 | 20,97,70 | 6,121,60 | 5,146,47 | −6.5 |
| 184.75,411.25 | .35 | 12,99,54 | 6,121,44 | 5,143,34 | −2.5 |
| 185.25,411.75 | .85 | 53,117,64 | 47,144,62 | 47,171,59 | −3 |

前四点 full 的 R 同为 5，最后一点 half/full 的 R 同为 47。这与局部平台／裁切相容，但没有定位到 native 内部哪一层，也没有证明一个唯一模型。不能用这五点宣布全局物理非线性，或把大多数近中点像素宣称为普遍线性。

## 方法与限制

原图 2× 整数像素、固定世界 ROI `[165.5,397.5,209.5,441.5]`，不配准、不插值。保留全部六姿态、轨道混杂区域、四个阈值和预先固定的 inset 分箱。源 G180 在完整像素处是 **encoded-sRGB** 中点，在线性光下仅为完整 G 增量约 0.4069597；AA 像素另有最多 ±0.5 输入 byte 舍入误差，不能据此推出 native 输出误差界。仅有一个空间方向的 G 扰动，不能识别完整颜色矩阵、唯一采样位置或厚度。

原 [v1 计划](analysis-plan.json) 和旧脚本完整保留。独立审阅在新像素分析前发现 pooled-round p99 会稀释某一轮漂移，故另存 [v1_1 计划](analysis-plan-v1_1.json) 与 `../analyze-midpoint-v1_1.py`，逐轮逐 RGB 计算空间 p99，任一超过 3 即拒绝；没有放宽门槛。修订时采集已开始，此时点已写入计划。合成变异验证：单轮 3% 像素为 10 byte 时 pooled p99=0，正确的该轮 p99=10。

正式结果在 [analysis.json](analysis.json)，逐像素值在六个 `*-midpoint-original-byte.npz`。源、计划、原索引与原 PNG 均保留 SHA；`source-verification.json` 保存源身份。分析复用既有冻结 native parser，不改变 runtime。

本轮两份新捕获的原始 JSONL trace 经过完整哈希校验后无损归档，再删除未压缩副本及模拟器内同哈希副本；PNG、session、原始收据和结果未变。243,079,685 bytes 原 trace 以 25,460,824 bytes 归档，具体成员和恢复命令见 [trace-storage-receipt.json](trace-storage-receipt.json)。重跑完整 trace 验证前，在各捕获目录执行 `tar -xzf traces-original-jsonl.tar.gz -C .`；原解析路径和原内容哈希将恢复。

下一项应区分位置相关颜色响应、颜色转换与通道采样的顺序、直接背景与光学层混合。单个 G 扰动不足以区分；继续保留多色星形作为空间追踪输入，不直接部署拟合的全局 saturation。
